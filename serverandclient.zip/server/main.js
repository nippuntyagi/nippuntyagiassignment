import { Meteor } from 'meteor/meteor';
UserPost = new Meteor.Collection('userpost');

Meteor.startup(() => {
  // code to run on server at startup
 Meteor.publish('allUserPost', function(){
	return UserPost.find({}, {sort: {date: -1}});
  });
	});
