import { Template } from 'meteor/templating';
import { ReactiveVar } from 'meteor/reactive-var';
import { Meteor } from 'meteor/meteor'

UserPost = new Meteor.Collection('userpost');
Meteor.subscribe('allUserPost');
import './main.html';

Template.register.events({
    'submit #register-form' : function(e) {
      e.preventDefault();
      var email = $('#account-email').val();
      var password = $('#account-password').val();
	  var name = $('#account-name').val();
        // Trim and validate the input

      Accounts.createUser({email: email, password : password, name : name}, function(err){
          if (err) {
			console.log(err);
          } else {
             console.log("record inserted");
          }

        });

      return false;
    }
  });

Template.login.events({

    'submit #login-form' : function(e, t){
      e.preventDefault();
      // retrieve the input field values
      var email = $('#login-email').val()
        , password = $('#login-password').val();

        Meteor.loginWithPassword(email, password, function(err){
        if (err){
          
			console.log(err);
			}
        else{
           console.log("The user has been logged in.")
			}
	  });
         return false; 
      }
  });

Template.dashboard.events({
    'click #post' : function(e) {
	e.preventDefault();
    var post = $('#userpost').val();
	var email = Meteor.user().emails[0].address;
	UserPost.insert({
	userName:  email,
	date: new Date().toTimeString(),
	userId: this.userId,
	userpost: post
});
console.log(email);
console.log(post);
}
});

Template.header.events({
	'click .logout': function(event){
        event.preventDefault();
        Meteor.logout();
    }
	});

Template.header.helpers({
currentuser: function(){
    return Meteor.user().emails[0].address;
	//use this in html to get result
	//currentUser.emails.[0].address
}
});

Template.recentposts.helpers({
post: function(){
return UserPost.find({}, {sort: {date: -1}});
}
});

